# Projeto de Reconhecimento de Texto com Imagens 📸

Bem-vindo ao meu projeto de reconhecimento de texto, desenvolvido como parte do desafio da DIO! 🚀

## 📚 Objetivo do Projeto

O objetivo deste projeto foi explorar e aplicar técnicas de reconhecimento de texto a partir de imagens, utilizando ferramentas de desenvolvimento modernas. A proposta era criar um pipeline completo que englobasse desde a obtenção das imagens até a extração e análise do texto contido nelas.

## 🛠️ Ferramentas Utilizadas

Para realizar este projeto, utilizei as seguintes ferramentas e bibliotecas:

- **Python**: Linguagem de programação principal para o desenvolvimento do script de reconhecimento de texto.
- **Tesseract-OCR**: Ferramenta open-source para OCR (Optical Character Recognition).
- **OpenCV**: Biblioteca de visão computacional utilizada para manipulação das imagens.
- **Pillow**: Biblioteca de processamento de imagens em Python.
- **Git e GitHub**: Controle de versão e repositório para armazenar e compartilhar o projeto.

## 📝 Passo a Passo do Desenvolvimento

### 1. Coleta das Imagens
- As imagens utilizadas no projeto foram coletadas e armazenadas na pasta `inputs/`.
- As imagens selecionadas variam em complexidade e qualidade, permitindo um teste mais robusto do reconhecimento de texto.

### 2. Processamento das Imagens
- As imagens passaram por um pré-processamento utilizando OpenCV para melhorar a precisão do OCR.
- As técnicas de pré-processamento incluíram conversão para escala de cinza, aumento de contraste e remoção de ruídos.

### 3. Reconhecimento de Texto
- Utilizei a biblioteca Tesseract-OCR para extrair o texto das imagens pré-processadas.
- O texto extraído foi armazenado em arquivos `.txt` na pasta `output/`.

### 4. Análise dos Resultados
- Realizei uma análise básica dos textos extraídos, comparando com o conteúdo esperado e identificando possíveis melhorias.
- Insights sobre a performance do OCR em diferentes condições de imagem foram documentados.

### 5. Documentação e Compartilhamento
- O projeto foi documentado detalhadamente e está disponível neste repositório.
- Screenshots e exemplos dos resultados podem ser encontrados abaixo.

## 📊 Resultados Obtidos

Os resultados do reconhecimento de texto variaram conforme a qualidade das imagens, com alguns desafios em imagens de baixa qualidade. A seguir, alguns exemplos de resultados obtidos:

### Exemplo 1: Imagem Limpa
![Resultado 1](output/exemplo1.png)
> Texto Extraído: "Este é um exemplo de texto extraído com sucesso."

### Exemplo 2: Imagem com Ruído
![Resultado 2](output/exemplo2.png)
> Texto Extraído: "Alguns erros foram identificados, mas o OCR ainda conseguiu capturar a maioria do texto."

## 💡 Insights e Aprendizados

- **Qualidade da Imagem**: A qualidade da imagem influencia diretamente na precisão do OCR. Imagens de alta resolução e bem iluminadas proporcionam melhores resultados.
- **Pré-processamento**: O uso de técnicas de pré-processamento como binarização e remoção de ruído pode melhorar significativamente a taxa de sucesso na extração de texto.
- **Desafios**: O reconhecimento de texto em imagens com fundo complexo ou texto manuscrito ainda apresenta desafios, sendo áreas potenciais para melhorias futuras.

## 🛠️ Possíveis Melhorias

Para versões futuras deste projeto, penso em implementar:

- **Correção Ortográfica**: Aplicação de uma etapa de pós-processamento para corrigir erros ortográficos no texto extraído.
- **Suporte a Manuscritos**: Exploração de técnicas avançadas de OCR para reconhecimento de texto manuscrito.
- **Automação com Batch Processing**: Implementar um sistema de processamento em lote para lidar com grandes quantidades de imagens de forma eficiente.

## 📁 Estrutura do Repositório

```bash
├── inputs/
│   ├── image1.jpg
│   ├── image2.jpg
│   └── ...
├── output/
│   ├── result1.txt
│   ├── result2.txt
│   └── ...
├── README.md
└── script.py
